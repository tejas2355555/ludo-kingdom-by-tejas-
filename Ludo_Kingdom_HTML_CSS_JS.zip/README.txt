LUDO KINGDOM - Separated HTML, CSS and JavaScript

Files:
- index.html: page structure
- style.css: all styling and animations
- script.js: game logic and interactions

How to run:
1. Extract this ZIP file.
2. Keep all three files in the same folder.
3. Open index.html in a modern browser.

Internet is required for the Google Font to load; the game itself runs locally.
