const $=s=>document.querySelector(s),sleep=ms=>new Promise(r=>setTimeout(r,ms)),esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const CN=['Red','Green','Yellow','Blue'],CL=['#e53935','#43a047','#fdd835','#1e88e5'],AV=['🦁','🐯','🦊','🐼'];
const PATH=[[6,1],[6,2],[6,3],[6,4],[6,5],[5,6],[4,6],[3,6],[2,6],[1,6],[0,6],[0,7],[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[6,9],[6,10],[6,11],[6,12],[6,13],[6,14],[7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[8,9],[9,8],[10,8],[11,8],[12,8],[13,8],[14,8],[14,7],[14,6],[13,6],[12,6],[11,6],[10,6],[9,6],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0],[7,0],[6,0]];
const STR=[[[7,1],[7,2],[7,3],[7,4],[7,5]],[[1,7],[2,7],[3,7],[4,7],[5,7]],[[7,13],[7,12],[7,11],[7,10],[7,9]],[[13,7],[12,7],[11,7],[10,7],[9,7]]];
const BASE=[[0,0],[0,9],[9,9],[9,0]],SAFE=new Set([0,8,13,21,26,34,39,47]),SEATS={2:[0,2],3:[0,1,2],4:[0,1,2,3]},MASK=[0,[4],[0,8],[0,4,8],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]],CEN=[[7.5,6.9],[6.9,7.5],[7.5,8.1],[8.1,7.5]];
let G=null,TK={},MV=new Set(),gid=0,CF={n:2,seats:[],lvl:'medium',mode:'cpu'};
let S={sound:true,music:true,vol:.6,theme:'dark',auto:true,bg:'auto'};try{Object.assign(S,JSON.parse(localStorage.getItem('lk_set')||'{}'))}catch(e){}
const sv=()=>{try{localStorage.setItem('lk_set',JSON.stringify(S))}catch(e){}};
function theme(){document.documentElement.dataset.theme=S.theme}theme();
/* audio */
let ac;function A(){if(!ac)try{ac=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}if(ac&&ac.state=='suspended')ac.resume();return ac}
function tone(f,d,t='sine',v=.15,w=0){if(!S.sound)return;const a=A();if(!a)return;const o=a.createOscillator(),g=a.createGain(),s=a.currentTime+w;o.type=t;o.frequency.setValueAtTime(f,s);g.gain.setValueAtTime(Math.max(.0002,v*S.vol),s);g.gain.exponentialRampToValueAtTime(.0001,s+d);o.connect(g);g.connect(a.destination);o.start(s);o.stop(s+d)}
const sfx={click:()=>tone(660,.08,'square',.1),dice:()=>{for(let i=0;i<8;i++)tone(180+Math.random()*300,.05,'triangle',.25,i*.085)},step:()=>tone(520,.07,'sine',.25),cap:()=>{for(let i=0;i<6;i++)tone(420-i*55,.12,'sawtooth',.2,i*.05)},win:()=>[523,659,784,1047,784,1047,1319].forEach((f,i)=>tone(f,.28,'triangle',.3,i*.15))};
const NOTES=[262,330,392,523,392,330,294,392];let ni=0;
setInterval(()=>{if(G&&!G.over&&!G.paused&&S.music&&S.sound&&ac&&ac.state=='running')tone(NOTES[ni++%8],.4,'sine',.07)},450);
function toggleSnd(){S.sound=!S.sound;sv()}
/* nav */
function show(id){document.querySelectorAll('.scr:not(.ov)').forEach(e=>e.classList.toggle('on',e.id==id));if(id=='menu')$('#resBtn').style.display=localStorage.getItem('lk_save')?'':'none'}
function openSettings(){$('#sSnd').checked=S.sound;$('#sMus').checked=S.music;$('#sAuto').checked=S.auto;syncBg();$('#sVol').value=S.vol;$('#sTh').value=S.theme;let h=[];try{h=JSON.parse(localStorage.getItem('lk_hist')||'[]')}catch(e){}$('#hist').innerHTML=h.length?h.map(x=>`🏆 ${esc(x.w)} won a ${x.n}-player game · ${x.t}`).join('<br>'):'No games finished yet.';show('set')}
function playNow(){startGame({n:2,seats:[{name:'You',ai:false},{name:'CPU',ai:true}],lvl:'medium'})}
function openSetup(m){CF.mode=m;CF.n=2;CF.seats=[0,1,2,3].map(k=>({...(m=='friends'?{name:'Player '+(k+1),ai:false}:{name:k?'CPU '+k:'You',ai:k>0}),c:SEATS[2][k]}));$('#stTitle').textContent=m=='friends'?'Play with Friends':'Computer Mode';drawSetup();show('setup')}
function drawSetup(){$('#cnt').innerHTML=[2,3,4].map(n=>`<button class="btn s ${CF.n==n?'on':''}" onclick="setN(${n})">${n} Players</button>`).join(' ');
$('#seats').innerHTML=CF.seats.slice(0,CF.n).map((s,k)=>`<div class="row"><select style="width:100px" onchange="pickC(${k},+this.value)">${CN.map((nm,i)=>`<option value="${i}" ${s.c==i?'selected':''}>${['🔴','🟢','🟡','🔵'][i]} ${nm}</option>`).join('')}</select><input maxlength="10" value="${esc(s.name)}" oninput="CF.seats[${k}].name=this.value"><select onchange="CF.seats[${k}].ai=this.value=='1'"><option value="0" ${s.ai?'':'selected'}>Human</option><option value="1" ${s.ai?'selected':''}>CPU</option></select></div>`).join('')}
/* game setup */
function startGame(cfg){const c=JSON.parse(JSON.stringify(cfg));G={id:++gid,cfg:c,lvl:c.lvl,pl:c.seats.map((s,k)=>{const cc=s.c??SEATS[c.n][k];return{c:cc,name:(s.name||'').trim()||CN[cc],ai:s.ai}}).sort((a,b)=>a.c-b.c),T:[0,1,2,3].map(()=>[-1,-1,-1,-1]),turn:0,phase:'roll',sixes:0,dice:1,paused:false,over:false};
$('#win').classList.remove('on');$('#pause').classList.remove('on');begin()}
function resume(){try{G=JSON.parse(localStorage.getItem('lk_save'));G.id=++gid;G.phase='roll';G.paused=false;begin()}catch(e){localStorage.removeItem('lk_save');show('menu')}}
function begin(){if(S.bg=='auto')setBg('auto');buildBoard();face(1);show('game');A();setMsg(P().name+'’s turn — roll the dice');render();updateUI();kick()}
const P=()=>G.pl[G.turn],setMsg=t=>$('#msg').textContent=t;
function buildBoard(){const b=$('#board');let h='';
BASE.forEach(([r,c],i)=>h+=`<div class="bs" style="grid-area:${r+1}/${c+1}/${r+7}/${c+7};background:${CL[i]}"><i></i></div>`);h+='<div class="ct"></div>';
PATH.forEach(([r,c],i)=>{const st=i%13==0?CL[i/13]:'';h+=`<div class="cl" style="grid-area:${r+1}/${c+1};${st?'background:'+st:''}">${SAFE.has(i)?'★':''}</div>`});
STR.forEach((a,i)=>a.forEach(([r,c])=>h+=`<div class="cl" style="grid-area:${r+1}/${c+1};background:${CL[i]}"></div>`));
b.innerHTML=h;TK={};G.pl.forEach(({c})=>{TK[c]=[];for(let t=0;t<4;t++){const e=document.createElement('div');e.className='tk';e.style.setProperty('--c',CL[c]);e.innerHTML='<svg viewBox="0 0 40 56"><g stroke="rgba(0,0,0,.55)" stroke-width="1.6" stroke-linejoin="round"><ellipse cx="20" cy="50" rx="15" ry="5" fill="var(--c)"/><path d="M10 49Q13 32 17 25H23Q27 32 30 49Z" fill="var(--c)"/><ellipse cx="20" cy="25" rx="10" ry="3.5" fill="var(--c)"/><circle cx="20" cy="15" r="9.5" fill="var(--c)"/></g><ellipse cx="16.5" cy="11.5" rx="3.5" ry="2.5" fill="#fff" opacity=".65"/><path d="M15 30Q13 40 13 46" stroke="#fff" stroke-width="2" opacity=".35" fill="none"/><ellipse cx="20" cy="49" rx="11" ry="2.5" fill="#000" opacity=".15"/></svg>';e.onclick=()=>tokClick(c,t);b.appendChild(e);TK[c].push(e)}});
$('#dice').innerHTML='<div class="cube">'+[1,6,2,5,3,4].map(n=>`<div class="f f${n}">${[0,1,2,3,4,5,6,7,8].map(i=>`<span class="${MASK[n].includes(i)?'on':''}"></span>`).join('')}</div>`).join('')+'</div>'}
function pos(c,t){const p=G.T[c][t];if(p<0){const[r,q]=BASE[c];return[r+(t<2?2:4),q+(t%2?4:2)]}if(p<=50){const[r,q]=PATH[(c*13+p)%52];return[r+.5,q+.5]}if(p<=55){const[r,q]=STR[c][p-51];return[r+.5,q+.5]}return CEN[c]}
function render(){const g={},L=[];G.pl.forEach(({c})=>G.T[c].forEach((p,t)=>{const q=pos(c,t);L.push([c,t,q,p]);if(p>=0&&p<56)(g[q]=g[q]||[]).push(c+'_'+t)}));
L.forEach(([c,t,q,p])=>{const e=TK[c][t];let[r,x]=q,a=g[q],s=p==56?.7:1;if(a&&a.length>1){const k=a.indexOf(c+'_'+t);x+=(k-(a.length-1)/2)*.3;s=.8}e.style.setProperty('--s',s);e.style.left=x/15*100+'%';e.style.top=r/15*100+'%';e.style.zIndex=MV.has(c+'_'+t)?40:3+(r|0);e.classList.toggle('can',MV.has(c+'_'+t))});document.querySelectorAll('.gh').forEach(e=>e.remove());if(G.phase=='move')MV.forEach(k=>{const[c,t]=k.split('_').map(Number),o=G.T[c][t],np=o<0?0:o+G.dice;G.T[c][t]=np;const q=pos(c,t);G.T[c][t]=o;const g=document.createElement('div'),a=(c*13+np)%52;g.className='gh'+(np<=50&&!SAFE.has(a)&&hit(c,a)?' cp':'');g.style.left=q[1]/15*100+'%';g.style.top=q[0]/15*100+'%';g.onclick=()=>tokClick(c,t);$('#board').appendChild(g)})}
let DN=0;function face(v){const o={1:[0,0],6:[0,180],2:[0,-90],5:[0,90],3:[-90,0],4:[90,0]}[v],k=720*(++DN),c=$('#dice .cube');if(c)c.style.transform=`rotateX(${o[0]+k}deg) rotateY(${o[1]+k}deg)`}
function updateUI(){if(!G)return;const p=P();$('#chips').innerHTML=G.pl.map((q,i)=>`<div class="chip${i==G.turn?' act':''}" style="--c:${CL[q.c]}"><b>${AV[q.c]}</b><span>${esc(q.name)}${q.ai?' 🤖':''}</span><em>🏠 ${G.T[q.c].filter(x=>x==56).length}/4</em></div>`).join('');$('#dice').style.setProperty('--pc',CL[p.c]);$('#rollbtn').disabled=G.phase!=='roll'||p.ai||G.paused}
function save(){try{localStorage.setItem('lk_save',JSON.stringify(G))}catch(e){}}
async function W(ms){const id=G&&G.id;await sleep(ms);while(G&&G.paused&&G.id==id)await sleep(100);if(!G||G.id!=id)throw 0}
function kick(){if(G.phase=='roll'&&P().ai&&!G.over)W(900).then(()=>roll()).catch(()=>{})}
function humanRoll(){if(G&&G.phase=='roll'&&!P().ai&&!G.paused){sfx.click();roll().catch(()=>{})}}
function legal(c,d){const m=[];G.T[c].forEach((p,t)=>{if(p<0?d==6:p+d<=56)m.push(t)});return m}
async function roll(){if(!G||G.phase!=='roll'||G.paused)return;G.phase='busy';MV=new Set();render();updateUI();const dc=$('#dice');dc.classList.remove('roll');void dc.offsetWidth;dc.classList.add('roll');sfx.dice();

const v=1+crypto.getRandomValues(new Uint32Array(1))[0]%6;face(v);await W(850);G.dice=v;const p=P(),c=p.c;
if(v==6)G.sixes++;else G.sixes=0;
if(G.sixes>=3){setMsg('Three sixes in a row — turn lost!');await W(1200);return next()}
const m=legal(c,v);
if(!m.length){setMsg('No moves possible');await W(1000);return next()}
if(p.ai){setMsg(p.name+' rolled '+v);await W(600);return doMove(c,aiPick(c,m,v))}
if(S.auto&&(m.length==1||m.every(t=>G.T[c][t]<0))){setMsg('You rolled '+v);await W(450);return doMove(c,m[0])}G.phase='move';MV=new Set(m.map(t=>c+'_'+t));setMsg('You rolled '+v+' — tap a glowing token');render();updateUI()}
function tokClick(c,t){if(!G||G.phase!=='move'||G.paused||P().ai||!MV.has(c+'_'+t))return;sfx.click();doMove(c,t).catch(()=>{})}
async function doMove(c,t){const d=G.dice,T=G.T[c];G.phase='busy';MV=new Set();updateUI();let cap=false;
if(T[t]<0){T[t]=0;sfx.step();render();hop(c,t);await W(300)}else for(let k=0;k<d;k++){T[t]++;sfx.step();render();hop(c,t);setMsg(P().name+': step '+(k+1)+' of '+d);await W(210)}
const p=T[t];
if(p<=50){const a=(c*13+p)%52;if(!SAFE.has(a))for(let o=0;o<4;o++)if(o!=c)G.T[o].forEach((q,j)=>{if(q>=0&&q<=50&&(o*13+q)%52==a){G.T[o][j]=-1;cap=true}});
if(cap){boom(PATH[a]);sfx.cap();setMsg('Captured! Extra turn');render();await W(600)}}
if(p==56&&!T.every(x=>x==56)){homeFx(c);await W(1100)}if(T.every(x=>x==56))return win(c);
if(d==6||cap||p==56){G.phase='roll';setMsg(P().name+' gets another turn'+(p==56?' (token home!)':''));save();render();updateUI();kick()}else next()}
function next(){G.sixes=0;G.turn=(G.turn+1)%G.pl.length;G.phase='roll';MV=new Set();setMsg(P().name+'’s turn — roll the dice');save();render();updateUI();kick()}
function boom(q){const e=document.createElement('div');e.className='boom';e.style.left=(q[1]+.5)/15*100+'%';e.style.top=(q[0]+.5)/15*100+'%';$('#board').appendChild(e);setTimeout(()=>e.remove(),750)}
/* AI */
function hit(c,a){return G.T.some((t,o)=>o!=c&&t.some(q=>q>=0&&q<=50&&(o*13+q)%52==a))}
function danger(c,a){let n=0;G.T.forEach((t,o)=>{if(o!=c)t.forEach(q=>{if(q>=0&&q<=50){const dd=(a-(o*13+q)%52+52)%52;if(dd>=1&&dd<=6)n++}})});return n}
function aiPick(c,m,d){const lv=G.lvl;if(lv=='easy')return m[Math.random()*m.length|0];let best=-1e9,bi=m[0];
m.forEach(t=>{const p=G.T[c][t],np=p<0?0:p+d;let s=Math.random()*(lv=='hard'?2:12);
if(np==56)s+=60;if(p<0)s+=40;if(np>50&&np<56)s+=22;
if(np<=50){const a=(c*13+np)%52;if(SAFE.has(a))s+=18;else{if(hit(c,a))s+=80;if(lv=='hard')s-=danger(c,a)*18}}
if(lv=='hard'&&p>=0&&p<=50){const a=(c*13+p)%52;if(!SAFE.has(a))s+=danger(c,a)*14}
s+=np*.4;if(s>best){best=s;bi=t}});return bi}
const PAWN='<svg viewBox="0 0 40 56"><g stroke="rgba(0,0,0,.55)" stroke-width="1.6" stroke-linejoin="round"><ellipse cx="20" cy="50" rx="15" ry="5" fill="var(--c)"/><path d="M10 49Q13 32 17 25H23Q27 32 30 49Z" fill="var(--c)"/><ellipse cx="20" cy="25" rx="10" ry="3.5" fill="var(--c)"/><circle cx="20" cy="15" r="9.5" fill="var(--c)"/></g><ellipse cx="16.5" cy="11.5" rx="3.5" ry="2.5" fill="#fff" opacity=".65"/></svg>';
$('#sp').innerHTML=[0,1,2,3].map(i=>`<div class="sw" style="--c:${CL[i]};animation-delay:${i*.15}s">${PAWN}</div>`).join('');
function enter(){A();sfx.click();show('menu')}
function setN(n){CF.n=n;for(let i=0;i<n;i++)CF.seats[i].c=SEATS[n][i];drawSetup()}
function pickC(k,v){const o=CF.seats.slice(0,CF.n).findIndex((s,i)=>i!=k&&s.c==v);if(o>=0)CF.seats[o].c=CF.seats[k].c;CF.seats[k].c=v;drawSetup()}
sfx.home=()=>[659,784,988,1319].forEach((f,i)=>tone(f,.22,'triangle',.3,i*.1));
function hop(c,t){const e=TK[c][t];e.classList.remove('hop');void e.offsetWidth;e.classList.add('hop')}
function burst(x,y,col,n=16,R=110){for(let i=0;i<n;i++){const e=document.createElement('div'),a=Math.random()*6.28,r=R*(.4+Math.random()*.6);e.className='pt';e.style.cssText=`left:${x}%;top:${y}%;--c:${col};--dx:${Math.cos(a)*r}px;--dy:${Math.sin(a)*r}px`;$('#board').appendChild(e);setTimeout(()=>e.remove(),950)}}
function banner(t){const e=document.createElement('div');e.className='ban';e.textContent=t;$('#board').appendChild(e);setTimeout(()=>e.remove(),1750)}
function homeFx(c){sfx.home();banner('🎉 '+P().name+': token home!');burst(50,50,CL[c],18,110);burst(50,50,'#ffd54f',12,80)}
async function victory(c){const w=G.pl.find(p=>p.c==c),xs=[5.6,6.9,8.1,9.4];G.T[c].forEach((p,t)=>{const e=TK[c][t];e.style.left=xs[t]/15*100+'%';e.style.top='50%';e.style.setProperty('--s',1.35);e.style.zIndex=60;e.style.animationDelay=t*.12+'s';e.classList.add('dance')});banner('🏆 '+w.name+' WINS! 🏆');sfx.win();for(let i=0;i<9;i++){burst(10+Math.random()*80,10+Math.random()*80,CL[Math.random()*4|0],18,90);await sleep(300)}}
const cv=$('#bg'),cx=cv.getContext('2d'),BG={clouds:['#3fb4f2','#cdeeff','#58b94a'],rain:['#44566b','#9db0c4','#3d6a4c'],blossom:['#ffc4e0','#fff0f7','#8fd18a'],tree:['#0a0f3d','#2c2f86','#12361f'],leaves:['#ff9f43','#fff1c1','#8d6e3a'],snow:['#6fa8dc','#eaf5ff','#f6fbff'],night:['#170a45','#5b2e9e','#2b1b5e'],candy:['#ffb3da','#c9f8e5','#ffe28a']};
let cur='clouds',PS=[],BW=0,BH=0,fl=0,sh=null;const R=(a,b)=>a+Math.random()*(b-a);
function syncBg(){['sBg','gBg'].forEach(i=>{const e=$('#'+i);if(e)e.value=S.bg})}
function setBg(v){S.bg=v;sv();cur=v=='auto'?Object.keys(BG).filter(k=>k!=cur)[Math.random()*7|0]:v;mk();syncBg()}
function mk(){BW=cv.width=innerWidth;BH=cv.height=innerHeight;const n={clouds:7,rain:170,blossom:55,leaves:40,snow:90,night:80,candy:24,tree:60}[cur];PS=Array.from({length:n},()=>({x:R(0,BW),y:R(0,BH),v:R(.6,2),s:R(.5,1.3),p:R(0,6.28),r:R(4,9),c:Math.random()}))}
addEventListener('resize',mk);
function cloud(x,y,s,col){cx.fillStyle=col;cx.beginPath();[[0,0,30],[30,-14,26],[60,0,30],[30,8,28]].forEach(([a,b,r])=>{cx.moveTo(x+(a+r)*s,y+b*s);cx.arc(x+a*s,y+b*s,r*s,0,6.3)});cx.fill()}
function tree(x,y,col){const u=Math.min(BW,BH)*.16;cx.fillStyle='#6d3f1b';cx.beginPath();cx.moveTo(x-u*.12,y);cx.lineTo(x-u*.07,y-u*1.3);cx.lineTo(x+u*.07,y-u*1.3);cx.lineTo(x+u*.12,y);cx.fill();cx.fillStyle=col;cx.beginPath();[[0,-1.6,1],[-.7,-1.3,.7],[.7,-1.3,.7],[-.4,-2.1,.7],[.45,-2.1,.7]].forEach(([a,b,r])=>{cx.moveTo(x+(a+r)*u,y+b*u);cx.arc(x+a*u,y+b*u,r*u,0,6.3)});cx.fill()}
function draw(t){requestAnimationFrame(draw);const c=BG[cur],s=t/1000;let g=cx.createLinearGradient(0,0,0,BH);g.addColorStop(0,c[0]);g.addColorStop(1,c[1]);cx.fillStyle=g;cx.fillRect(0,0,BW,BH);
if(cur=='night'){const mx=BW*.8,my=BH*.15,gr=cx.createRadialGradient(mx,my,10,mx,my,90);gr.addColorStop(0,'rgba(255,250,200,.9)');gr.addColorStop(1,'rgba(255,250,200,0)');cx.fillStyle=gr;cx.fillRect(mx-100,my-100,200,200);cx.fillStyle='#fffbe0';cx.beginPath();cx.arc(mx,my,34,0,6.3);cx.fill()}
cx.fillStyle=c[2];cx.beginPath();cx.ellipse(BW*.3,BH*1.1,BW*.8,BH*.2,0,0,6.3);cx.fill();cx.globalAlpha=.8;cx.beginPath();cx.ellipse(BW*.9,BH*1.12,BW*.6,BH*.17,0,0,6.3);cx.fill();cx.globalAlpha=1;
if(cur=='blossom')tree(BW*.12,BH,'#f7a8cc');if(cur=='tree')tree(BW*.85,BH,'#1f6b3a');
PS.forEach((p,i)=>{
if(cur=='clouds'){p.x+=p.v*.35;if(p.x>BW+200)p.x=-220;cloud(p.x,40+p.p/6.28*BH*.4,p.s*1.5,'rgba(255,255,255,.92)')}
else if(cur=='rain'){if(i<6){p.x+=p.v*.2;if(p.x>BW+200)p.x=-220;cloud(p.x,20+p.p*12,p.s*2,'rgba(70,82,100,.95)')}else{p.y+=p.v*9;p.x-=2;if(p.y>BH){p.y=-20;p.x=R(0,BW+100)}cx.strokeStyle='rgba(210,230,255,.7)';cx.lineWidth=1.5;cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(p.x+4,p.y-p.r*2.4);cx.stroke()}}
else if(cur=='blossom'||cur=='leaves'||cur=='snow'){const sn=cur=='snow';p.y+=p.v*(sn?.7:1);p.x+=Math.sin(s*1.5+p.p)*.9+.4;if(p.y>BH+10){p.y=-10;p.x=R(0,BW)}if(p.x>BW+10)p.x=-10;cx.save();cx.translate(p.x,p.y);cx.rotate(s*p.v+p.p);cx.fillStyle=sn?'#fff':cur=='blossom'?(p.c>.5?'#ffb3d1':'#ff8fbd'):['#e65100','#ff9800','#c62828','#fbc02d'][p.c*4|0];cx.beginPath();if(sn)cx.arc(0,0,p.r*.45,0,6.3);else cx.ellipse(0,0,p.r*(cur=='leaves'?1.2:1),p.r*.6,0,0,6.3);cx.fill();cx.restore()}
else if(cur=='tree'){if(i<42){const u=Math.min(BW,BH)*.16,a=.4+.6*Math.abs(Math.sin(s*2+p.p*3)),x=BW*.85+Math.cos(p.p)*p.c*u*1.5,y=BH-u*1.6+Math.sin(p.p)*p.c*u*1.1;cx.fillStyle='rgba(255,246,160,'+a+')';cx.shadowColor='#ffe45e';cx.shadowBlur=10;cx.fillRect(x-1.5,y-5,3,10);cx.fillRect(x-5,y-1.5,10,3);cx.shadowBlur=0}else{p.x+=Math.sin(s+p.p)*.6;p.y+=Math.cos(s*.8+p.p)*.5;const a=.4+.6*Math.abs(Math.sin(s*2+p.p));cx.fillStyle='rgba(200,255,120,'+a+')';cx.shadowColor='#c6ff5e';cx.shadowBlur=12;cx.beginPath();cx.arc(p.x,p.y,2.5,0,6.3);cx.fill();cx.shadowBlur=0}}
else if(cur=='night'){cx.fillStyle='rgba(255,255,255,'+(.4+.6*Math.abs(Math.sin(s*2+p.p)))+')';cx.fillRect(p.x,p.y*.7,p.s*2,p.s*2)}
else if(cur=='candy'){p.y-=p.v*.5;p.x+=Math.sin(s+p.p)*.5;if(p.y<-40){p.y=BH+40;p.x=R(0,BW)}cx.fillStyle='rgba(255,255,255,.3)';cx.strokeStyle='rgba(255,255,255,.8)';cx.lineWidth=2;cx.beginPath();cx.arc(p.x,p.y,p.r*3,0,6.3);cx.fill();cx.stroke()}});
if(cur=='rain'){if(Math.random()<.003)fl=1;if(fl>0){cx.fillStyle='rgba(255,255,255,'+fl*.5+')';cx.fillRect(0,0,BW,BH);fl-=.06}}
if(cur=='night'){if(!sh&&Math.random()<.004)sh={x:R(BW*.4,BW),y:R(0,BH*.3),l:0};if(sh){sh.l+=.03;const x=sh.x-sh.l*400,y=sh.y+sh.l*200;cx.strokeStyle='#fff';cx.lineWidth=2;cx.beginPath();cx.moveTo(x,y);cx.lineTo(x+60,y-30);cx.stroke();if(sh.l>1)sh=null}}}
setBg(S.bg);requestAnimationFrame(draw);
/* end / pause */
async function win(c){const id=G.id;G.over=true;G.phase='over';localStorage.removeItem('lk_save');const w=G.pl.find(p=>p.c==c);
const rk=[...G.pl].sort((a,b)=>(a==w?-1:b==w?1:0)||sum(b.c)-sum(a.c));
$('#wName').textContent=AV[c]+' '+w.name+' wins!';$('#wRank').innerHTML=rk.map((p,i)=>`<div class="rk">${i+1}. ${AV[p.c]} <b>${esc(p.name)}</b> — ${G.T[p.c].filter(x=>x==56).length}/4 home</div>`).join('');
try{const h=JSON.parse(localStorage.getItem('lk_hist')||'[]');h.unshift({w:w.name,n:G.pl.length,t:new Date().toLocaleDateString()});localStorage.setItem('lk_hist',JSON.stringify(h.slice(0,10)))}catch(e){}
render();updateUI();await victory(c);if(!G||G.id!=id)return;$('#win').classList.add('on');confetti()}
const sum=c=>G.T[c].reduce((a,p)=>a+p+1,0);
function pauseG(){sfx.click();G.paused=true;updateUI();$('#gSnd').checked=S.sound;$('#gMus').checked=S.music;$('#gVol').value=S.vol;$('#gTh').value=S.theme;syncBg();$('#pause').classList.add('on')}
function fs(){try{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen().catch(()=>{})}catch(e){}}
function resumeG(){sfx.click();G.paused=false;$('#pause').classList.remove('on');updateUI()}
function exitG(){sfx.click();if(G&&!G.over)save();G=null;$('#win').classList.remove('on');show('menu')}
function confetti(){const cv=$('#cf'),x=cv.getContext('2d');cv.width=innerWidth;cv.height=innerHeight;const ps=Array.from({length:170},()=>({x:Math.random()*cv.width,y:-Math.random()*cv.height,v:2+Math.random()*4,s:5+Math.random()*7,c:CL[Math.random()*4|0],r:Math.random()*6,w:Math.random()*.2-.1}));let f=0;
(function L(){x.clearRect(0,0,cv.width,cv.height);ps.forEach(p=>{p.y+=p.v;p.r+=p.w*3;p.x+=Math.sin(p.r);x.fillStyle=p.c;x.fillRect(p.x,p.y,p.s,p.s*.6)});if(f++<500&&$('#win').classList.contains('on'))requestAnimationFrame(L);else x.clearRect(0,0,cv.width,cv.height)})()}
show('splash');
